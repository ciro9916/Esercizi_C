#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	// intero 4 byte
		int n,vet[100];
		int somma=0,i=0,max=INT_MIN,min=INT_MAX;
		do {
		    printf("Inserisci un numero (0 per terminare): ");
		    scanf("%d", &n);
		
			if(n!=0){
				somma=somma+n;
			
				if(max<n)
				  max=n;
				
				if(min>n)
				  min=n;
				  
				vet[i]=n;
				i++;	
			}		
			
		} while (n != 0);
		float media=(float) somma/i;
		float sommaQuadrati = 0;
		for(int k = 0; k < i; k++){
		    sommaQuadrati += vet[k] * vet[k];
		}
		
		float mediaQuadrati = sommaQuadrati / i;
		float varianza = mediaQuadrati - (media * media);

		int moda = 0;
		int maxCount = 0;
		
		for(int z = 0; z < i; z++){
		    int temp = vet[z];
		    int p = 0;
		
		    for(int r = 0; r < i; r++){
		        if(temp == vet[r])
		            p++;
		    }
		
		    if(p > maxCount){
		        maxCount = p;
		        moda = temp;
		    }
		}
		
	printf("Moda : %d\nMedia : %.2f\nSomma : %d\nMax : %d\nMin : %d\nVarianza : %.2f",
       moda, media, somma, max, min, varianza);		

			
}