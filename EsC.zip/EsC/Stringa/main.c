#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

void main(int argc, char *argv[]) {
	
	/*
	char s[100];
	
	do{
		printf("inserisci una stringa di min 2 lettere: ");
		scanf("%s",s);	
	}while(strlen(s)<2);
	
	int i=0,j=strlen(s)-1,z=-1;
	
	while(i<j && z==-1){
		
		if(s[i]!=s[j]){
			z=0;
		}
		i++;
		j--;
	}
	
	if(z==-1){
		printf("%s e' palindroma ",s);
	}else{
		printf("%s non e' palindroma ",s);
	}
			
	*/
	int tg[6],c;
	for(int i=0;i<6;i++){
		scanf("%d",&tg[i]);
	}
	
	printf("Inserisci valore da cercare : ");
	scanf("%d",&c);
	
	int k=0,j=0;
	while(j<6 && k==0){
		if(tg[j]>=c){
			k=1;
		}
		j++;
	}
	
	if(k==0){
		printf("Elemento non presente");
	}else{
		printf("%d posizionato in %d try",c,j);
	}
	
}