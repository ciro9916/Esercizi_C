#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

void main() {
 /*char c,c2;

    printf("Inserisci il valore: ");
    scanf("%c", &c);   
	c2=c+'A'-'a';
    printf("%c in maiuscolo e' %c\n", c,c2);
    printf("un intero occupa %d byte\n",sizeof(int));
	printf("un intero occupa %d byte\n",sizeof(c2));
	
	
	printf("--------------------------------------------------------------------------------");
	
	int a,b,ci;
	printf("Inserisci due numeri : ");
	scanf("%d%d",&a,&b);
	printf("%d + %d = %d",a,b,a+b);

	unsigned x =  0x7FFFFFFF;
	printf("%d",x+1);
	*/
	int n1,n2;
	float k;
	
	printf("inserisci 2 numeri: ");
	scanf("%d%d",&n1,&n2);
	k=(float) n1/n2;
	printf("%d / %d = %f",n1,n2,k);
}