#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	// intero 4 byte
	
	int vet[100];
	/*int i=0;
	int n=0;
	do{
		printf("Inserisci un numero (0 per terminare ): ");
		scanf("%d",&n);
		if(n!=0){
		  vet[i]=n;
		  i++;	
		}
		
	}while(n!=0 && i<100);
	
	int j=0,u=i-1;
	
	while(j<u){
		int tmp;
		tmp=vet[j];
		vet[j]=vet[u];
		vet[u]=tmp;
		j++;
		u--;
	}
	
	printf("ci sono %d valori \n\n",i);
	for(int k=0;k<i;k++){
		printf("%d - valore %d / %d\n",vet[k],k+1,i);
	}
	*/
	
			int x;
			do {
			    printf("Inserisci numero: ");
			    scanf("%d", &x);
			} while (x > 1000 || x < 1);
			
			int b;
			do {
			    printf("Inserisci una base: ");
			    scanf("%d", &b);
			} while (b > 16 || b < 2);
			
			
			int r, c = 0;
			
			while (x != 0) {
			    r = x % b;
			    vet[c] = r;
			    x = x / b;
			    c++;
			}
			
			// stampa al contrario
			for (int y = c - 1; y >= 0; y--) {
			    if (vet[y] < 10)
			        printf("%d", vet[y]);
			    else
			        printf("%c", vet[y] - 10 + 'A');
			}
			
			printf("\n");

	
}