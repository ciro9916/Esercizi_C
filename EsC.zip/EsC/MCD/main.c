#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

void main() {
	int a=-1,b=-1;
	
	do{
		printf("Inserisci un valore maggiore di 0: ");
		scanf("%d",&a);
		if(a<1)
		    printf("IL numero deve essere maggiore di 0\n");
	}while(a<1);
	
	do{
		printf("Inserisci un valore minore di %d : ",a);
		scanf("%d",&b);
		if(b>=a)
		    printf("IL numero deve essere minore di %d \n",a);
	}while(b>=a);
	
	/*int i=a;
	int c=0,x=-1,g=0;
	while (c==0){
		if(a%i==0 && b%i==0)
		 {
		 	x=i;
		 	c=1;
		 }
		 g++;
		 i--;   
	}
	printf("il maggior comun divisore tra %d e %d e' %d\n e' stato trovato in %d ciclate",a,b,x,g);
	*/
	int A=a,B=b;
	int r=a%b;
	if(r!=0){
		while(r!=0){
		   a=b;
		   b=r;
		   r=a%b;	
		}
	}
	printf("il maggior comun divisore tra %d e %d e' %d\n",A,B,b);

}