#include <stdio.h>
#include <string.h>
#define MAXSIZE 100

/*int main(){
    typedef enum {ESCI,AGGIUNGI,CANCELLA,STAMPA,CERCA} azione;
    typedef char str[100];
    typedef enum{M,F} genere;
    
    // definizione persona
    typedef struct{
        str nome, cognome;
        int eta;
        genere g;
    } persona;
    
    // definizione agenda
    typedef struct{
        persona v[MAXSIZE];
        int n;
    } agenda;
    
    agenda a;
    a.n = 0;
    str per, n1, c1;
    int scelta = 0;
    
    do{
        printf("\n1) Aggiungi\n2) Cancella\n3) Stampa\n4) Cerca\n0) Esci\nScelta: ");
        scanf("%d", &scelta);
        
        switch(scelta){
            case 1:
                {  
                    if(a.n >= MAXSIZE){
                        printf("Agenda piena!\n");
                        break;
                    }
                    
                    persona p;
                    printf("Nome: "); 
                    scanf("%s", p.nome);  
                    
                    printf("Cognome: "); 
                    scanf("%s", p.cognome);  
                    
                    printf("Eta: "); 
                    scanf("%d", &p.eta);  
                    
                    printf("Genere (M=0, F=1): "); 
                    scanf("%d", (int*)&p.g);
                    
                    a.v[a.n++] = p;
                    printf("Persona aggiunta!\n");
                }
                break;
                
            case 2:
                {
                    printf("Inserisci nome da cercare: ");
                    scanf("%s", n1);
                    
                    printf("Inserisci cognome da cercare: ");
                    scanf("%s", c1);
                    
                    int trovato = 0;
                    for(int j = 0; j < a.n; j++){
                        persona c = a.v[j];
                        if(strcmp(n1, c.nome) == 0 && strcmp(c1, c.cognome) == 0){
                            for(int o = j; o < a.n - 1; o++){
                                a.v[o] = a.v[o + 1];
                            }
                            a.n--;
                            j--;  
                            trovato = 1;
                            printf("Persona cancellata!\n");
                        }  
                    }
                    if(!trovato){
                        printf("Persona non trovata.\n");
                    }
                }
                break;
                
            case 3:
                if(a.n == 0){
                    printf("Agenda vuota.\n");
                } else {
                    for(int j = 0; j < a.n; j++){
                        persona c = a.v[j];  
                        printf("Persona %d\nNome: %s\nCognome: %s\nEta: %d\nGenere (0=M, 1=F): %d\n",
                               (j+1), c.nome, c.cognome, c.eta, c.g);
                        printf("--------------------------------\n");
                    }
                }
                break;
                
            case 4:
                {
                    printf("Inserisci nome o cognome da cercare: ");
                    scanf("%s", per);
                    
                    int trovato = 0;
                    for(int j = 0; j < a.n; j++){
                        persona c = a.v[j];
                        if(strcmp(per, c.nome) == 0 || strcmp(per, c.cognome) == 0){
                            printf("\nNome: %s\nCognome: %s\nEta: %d\nGenere (0=M, 1=F): %d\n", 
                                   c.nome, c.cognome, c.eta, c.g);
                            printf("--------------------------------\n");
                            trovato = 1;
                        }  
                    }
                    if(!trovato){
                        printf("Nessuna persona trovata.\n");
                    }
                }
                break;
                
            case 0:
                printf("Uscita...\n");
                break;
                
            default:
                printf("Scelta non valida!\n");
                break;
        }
    } while(scelta != 0);
    
    return 0;
}*/

void main (){
	int x=5,y=8;
	
	int *p,*q;
	
	p=&x;q=&y;
}