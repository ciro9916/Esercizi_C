#define SIZE 100

typedef struct{
	int v[SIZE];
	int n;
}stack;

typedef enum{FALSE,TRUE} bool;

void init(stack *s);
void push(stack *s,int x);
int pop(stack *s);
// non modifica lo stack
bool isEmpty(stack s);
void destroy(stack* s);