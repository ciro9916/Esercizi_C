#include <stdio.h>
#include <string.h>
#include "stack.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
void init(stack *s){
	s->n=0;
}
void push(stack *s,int x){
	s->v[s->n++]=x;
}
int pop(stack *s){
	s->n--;
	return s->v[s->n];
}
// non modifica lo stack
bool isEmpty(stack s){
	return s.n==0;
}
void destroy(stack *s){
	//empty
}
int main(int argc, char *argv[]) {
	return 0;
}

void stringaS(char str[]){
    stack s;
    init(&s);
    
    for (int i=0; i<strlen(str); i++){
        if (str[i] == '+' || str[i] == 'x' || 
            str[i] == '-' || str[i] == '/'){
            
            int b = pop(&s);
            int a = pop(&s);
            int risultato = 0;
            
            if (str[i] == '+'){
                risultato = a + b;
            }
            else if (str[i] == 'x'){
                risultato = a * b;
            }
            else if (str[i] == '-'){
                risultato = a - b;
            }
            else if (str[i] == '/'){
                if (b != 0)
                    risultato = a / b;
            }
            
            push(&s, risultato);
            
        } else if (str[i] >= '0' && str[i] <= '9'){
            push(&s, str[i] - '0');
        }		
    }
}

