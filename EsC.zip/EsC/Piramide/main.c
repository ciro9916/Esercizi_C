#include <stdio.h>
#include <stdlib.h>

int h(int n, char da, char a, char per);

int main(int argc, char *argv[]) {
    int numDischi;
    
    printf("Torre di Hanoi\n");
    printf("Inserisci il numero di dischi: ");
    scanf("%d", &numDischi);
    
    printf("\nSoluzione:\n");
    h(numDischi, 'A', 'C', 'B');
    
    return 0;
}

int h(int n, char da, char a, char per) {
    if (n == 1) {
        printf("Sposta disco da %c a %c\n", da, a);
        return 0;
    }
    
    if(n>1){
    	h(n - 1, da, per, a);
	    h(1, da, a, per);
	    h(n - 1, per, a, da);
	 	
	}
       
    return 0;
}