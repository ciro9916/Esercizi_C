#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {

	int a,b,c;
	scanf("%d%d%d",&a,&b,&c);
	
	if(a<b){
		if(a<c){
			printf("%d ",a);
			printf("%d %d",b<c?b:c,b<c?b:c);
		}else
		 printf("%d %d %d",c,a,b);
	}else{
		if(b<c){
			printf("%d ",b);
			if(a<c)
			 	printf("%d %d",a,c);
			 else
			     printf("%d %d",c,a);	
			}else
		 printf("%d %d %d",c,b,a);
	}
		 printf("\n --------------------- \n");
		 int tmp;
		 if(a>b){
		 	tmp=a;a=b;b=tmp;
		 }if(a>c){
		 	tmp=a;a=c;c=tmp;
		 }if(b>c){
		 	tmp=b;b=c;c=tmp;
		 }
		printf("%d %d %d",a,b,c);
}