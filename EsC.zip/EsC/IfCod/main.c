#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	/*printf("Inserisci numero: ");
	int num;
	scanf("%d",&num);
	// 0 va nell'if, 1 si
	char msg="";
	if(num%2==0){
		printf("Il numero e' pari'");
		printf("\nFINE");
	}else{
		printf("e' dispari'");
	}
	printf(num%2==0?"\nbari":"\ndisbari");
	*/
	/*int eta;
	printf("Inserisci la tua eta: ");
	scanf("%d",&eta);
	if(eta>=22){
		printf("Adulto");
	}else if (eta>=14)
	     printf("Ragazzo");
	else
		printf("Bimbo");
	float altezza;
	float peso,IMC;
	printf("Inserisci altezza [metri]: ");
	scanf("%f",&altezza);
	printf("Inserisci peso [kili]: ");
	scanf("%f",&peso);
	
	IMC = (float) peso / ((altezza) * (altezza));
	printf("l'indice di massa corporea e' %f e sei ",IMC);
	if(IMC > 40){
		printf("Obesita classe III");
	}else if (IMC > 35){
	    printf("Obesita classe II");
	}else if (IMC > 30){
		printf("Obesita classe I");
	}else if (IMC > 25){
		printf("Sovrappeso");
	}else if(IMC > 18,51){
		printf("Normo peso");
	}else if(IMC > 17,51){
		printf("leggermente sotto peso");
	}else if (IMC > 16,01){
		printf("sottopeso");
	}else{
		printf("Gravezza media");
	}*/
	
		printf("Inserisci anno: ");
	int anno;
	scanf("%d",&anno);
	if(anno%4==0 ){
		if(anno%100==0){
			if(anno%400==0)
			   printf("bisestile");
			else
			   printf("non bisestile");   
		}else{
			printf("bisestile");
		}
	}else{
		 printf("\n Non e' 'bisestile ");  
	}
	
}






































