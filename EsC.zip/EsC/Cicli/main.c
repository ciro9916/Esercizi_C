#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

void main() {
	
	/*	int x;
		printf("Inserisci numero: ");
		scanf("%d",&x);
		int somma=0;
		while (x!=0){
			printf("Inserisci numero: ");
			scanf("%d",&x);
			somma+=x;
		}
		printf ("La somma e' di : %d",somma);
	
	int x;
	do{
		printf("Inserisci numero: ");
		scanf("%d",&x);
	}while(x>100 || x<1);
	
	int b;
	do{
		printf("Inserisci una base: ");
		scanf("%d",&b);
	}while(b>16 || b<1);
	
	int r;
	while(x!=0){
		if(x>=b){
			r=x%b;
			if(r<10)
			  	printf("%d",r);
			else
			   printf("%c",r-10+'A');
			x=x/b;
		}else{
			r=x;
			x=0;
		}
		
	}*/
	int c= 5/2;
	printf("5/2 = %d",c);
}