#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

void main() 
{/*
		int n;
		printf("Inserisci numero: ");
		scanf("%d",&n);
		switch(n)
		{
			case 1:
				printf("\n uno");
			break;
			case 2:
				printf("\n due");
			break;
			case 3:
				printf("\n tre");
			break;
			default:
				printf("\n GRANDE");
			break;	
		}
*/
	int mese;
	printf("Inserisci numero del mese: ");
	scanf("%d",&mese);
	
	switch(mese)
	{
		    case 1:
		    case 3:
		    case 5:
		    case 7:
		    case 8:
		    case 10:
		    case 12:
		        printf("\nHa 31 giorni");
		        break;
			case 2:
		        printf("\nHa 28 giorni");
		        break;
			case 4:
		    case 6:
		    case 9:
		    case 11:
		        printf("\nHa 30 giorni");
		        break;
		
		    default:
		        printf("\nMese non valido");
		        break;
	}
}