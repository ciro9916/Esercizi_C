#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

void main() {
 char c;

    printf("Inserisci il valore: ");
    scanf("%c", &c);   

    printf("%c in maiuscolo e' %c\n", c,c-32);
}