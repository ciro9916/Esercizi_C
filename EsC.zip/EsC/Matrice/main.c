#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

#define SIZE 3
int main(int argc, char *argv[]) {
	typedef int mat[SIZE][SIZE];
	
	mat m1,m2,m3;
	int i,j,k;
	
		
	for(i = 0; i < SIZE; i++) {
		for(j = 0; j < SIZE; j++) {
			printf("Inserisci valore nella prima matrice :");
			scanf("%d",&m1[i][j]);
		}
	}
	
	
	for(i = 0; i < SIZE; i++) {
		for(j = 0; j < SIZE; j++) {
					printf("Inserisci valore nella seconda matrice :");
			scanf("%d",&m2[i][j]);
		}
	}
	
	
	for(i = 0; i < SIZE; i++) {
		for(j = 0; j < SIZE; j++) {
				m3[i][j]=0;
				for (k=0 ; k<SIZE ;k++){
					m3[i][j]+= m1[i][k] * m2[k][j];
				}
		}
	}
	return 0;
}