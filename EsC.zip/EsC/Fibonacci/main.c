#include <stdio.h>
#include <stdlib.h>

int fibo(int n, int *contatore) {
    (*contatore)++;
    
    if (n == 0) {
        return 0;
    } else if (n == 1) {
        return 1;
    } else {
        return fibo(n-1, contatore) + fibo(n-2, contatore);
    }
}

int main() {
    int fib, contatore = 0;
    
    do {
        printf("Inserisci la posizione nella serie di Fibonacci: ");
        scanf("%d", &fib);
    } while (fib < 0);
    
    int risultato = fibo(fib, &contatore);
    printf("Fibonacci(%d) = %d\n", fib, risultato);
    printf("Numero di chiamate ricorsive: %d\n", contatore);
    
    return 0;
}

int partizione(int v[], int n){
	int j,i,p,t;
	if (n==0)
		return -1;
	p=v[0];i=1;
	return j;
	
}