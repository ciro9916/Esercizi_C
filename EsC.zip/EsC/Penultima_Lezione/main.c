#include <stdio.h>
#include <string.h>
#define MAXSIZE 100

typedef char str[100];
typedef enum{M,F} genere;

typedef struct{
    str nome, cognome;
    int eta;
    genere g;
} persona;

typedef struct{
    persona v[MAXSIZE];
    int n;
} agenda;

void init(agenda* a);
persona leggiPersona();
void stampaPersona(persona p);
void stampaAgenda(agenda a);
void aggiungi(agenda* a);
void cerca(agenda a, str testo);
void cancella(agenda* a, str n1, str c1);

int main(){
    agenda a;
    init(&a);
    str n1, c1, testo;
    int scelta = 0;
	
    do{
        printf("\n=== MENU AGENDA ===\n");
        printf("1) Aggiungi persona\n");
        printf("2) Cancella persona\n");
        printf("3) Stampa agenda completa\n");
        printf("4) Cerca persona\n");
        printf("5) Inizializza agenda (cancella tutto)\n");
        printf("0) Esci\n");
        printf("==================\n");
        printf("Scelta: ");
        scanf("%d", &scelta);
        
        switch(scelta){
            case 1:
                aggiungi(&a);
                break;
                
            case 2:
                if(a.n == 0){
                    printf("Agenda vuota, nessuna persona da cancellare.\n");
                } else {
                    printf("Inserisci nome della persona da cancellare: ");
                    scanf("%s", n1);
                    
                    printf("Inserisci cognome della persona da cancellare: ");
                    scanf("%s", c1);
                    
                    cancella(&a, n1, c1);
                }
                break;
                
            case 3:
                printf("\n=== AGENDA COMPLETA ===\n");
                stampaAgenda(a);
                break;
                
            case 4:
                if(a.n == 0){
                    printf("Agenda vuota, nessuna persona da cercare.\n");
                } else {
                    printf("Inserisci nome o cognome da cercare: ");
                    scanf("%s", testo);
                    cerca(a, testo);
                }
                break;
                
            case 5:
                {
                    char conferma;
                    printf("Sei sicuro di voler cancellare tutta l'agenda? (s/n): ");
                    scanf(" %c", &conferma);
                    if(conferma == 's' || conferma == 'S'){
                        init(&a);
                        printf("Agenda inizializzata (svuotata).\n");
                    } else {
                        printf("Operazione annullata.\n");
                    }
                }
                break;
                
            case 0:
                printf("\nUscita dal programma...\n");
                printf("Arrivederci!\n");
                break;
                
            default:
                printf("\n*** ERRORE: Scelta non valida! ***\n");
                printf("Inserisci un numero tra 0 e 5.\n");
                break;
        }
    } while(scelta != 0);
    
    return 0;
}

void init(agenda* a){
    a->n = 0;
}

persona leggiPersona(){
    persona p;
    
    printf("\n--- Inserimento nuova persona ---\n");
    printf("Nome: "); 
    scanf("%s", p.nome);  
    
    printf("Cognome: "); 
    scanf("%s", p.cognome);  
    
    printf("Eta: "); 
    scanf("%d", &p.eta);  
    
    printf("Genere (M=0, F=1): "); 
    scanf("%d", (int*)&p.g);
    
    return p;
}

void stampaPersona(persona p){
    printf("Nome: %s\n", p.nome);
    printf("Cognome: %s\n", p.cognome);
    printf("Eta: %d\n", p.eta);
    printf("Genere: %s\n", (p.g == M ? "M" : "F"));
    printf("--------------------------------\n");
}

void stampaAgenda(agenda a){
    if(a.n == 0){
        printf("Agenda vuota.\n");
    } else {
        printf("Totale persone in agenda: %d\n\n", a.n);
        for(int j = 0; j < a.n; j++){
            printf("Persona %d:\n", j+1);
            stampaPersona(a.v[j]);
        }
    }
}

void aggiungi(agenda* a){
    if(a->n >= MAXSIZE){
        printf("\n*** ATTENZIONE: Agenda piena! ***\n");
        printf("Non e' possibile aggiungere altre persone.\n");
        return;
    }
    
    persona p = leggiPersona();
    a->v[a->n++] = p; 
    printf("\n*** Persona aggiunta con successo! ***\n");
    printf("Totale persone in agenda: %d\n", a->n);
}

void cerca(agenda a, str testo){
    int trovato = 0;
    printf("\n=== RISULTATI RICERCA ===\n");
    for(int j = 0; j < a.n; j++){
        if(strcmp(testo, a.v[j].nome) == 0 || strcmp(testo, a.v[j].cognome) == 0){
            printf("\nTrovata:\n");
            stampaPersona(a.v[j]);
            trovato = 1;
        }  
    }
    if(!trovato){
        printf("Nessuna persona trovata con nome/cognome: %s\n", testo);
    } else {
        printf("Ricerca completata.\n");
    }
}

void cancella(agenda* a, str n1, str c1){
    int trovato = 0;
    int conta = 0;
    for(int j = 0; j < a->n; j++){
        if(strcmp(n1, a->v[j].nome) == 0 && strcmp(c1, a->v[j].cognome) == 0){
            for(int o = j; o < a->n - 1; o++){
                a->v[o] = a->v[o + 1];
            }
            a->n--;
            j--;  
            trovato = 1;
            conta++;
        }  
    }
    if(!trovato){
        printf("\n*** Persona non trovata ***\n");
        printf("Nessuna persona con nome '%s' e cognome '%s'\n", n1, c1);
    } else {
        printf("\n*** Cancellazione completata! ***\n");
        printf("Persone cancellate: %d\n", conta);
        printf("Persone rimanenti: %d\n", a->n);
    }
}