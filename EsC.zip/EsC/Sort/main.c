#include <stdio.h>
#include <stdlib.h>

/*int main() 
{
    int vet[10];

    for (int s = 0; s < 10; s++) {
        printf("Inserisci un valore: ");
        scanf("%d", &vet[s]);
    }

    int pos;
    for (int j = 0; j < 9; j++) {
        for (int i = j + 1; i < 10; i++) {
            if (vet[j] > vet[i]) {
                pos = vet[j];
                vet[j] = vet[i];
                vet[i] = pos;
            }
        }
    }

    for (int y = 0; y < 10; y++) {
        printf("%d\n", vet[y]);
    }

    return 0;
}*/


/*int main() {
    int v[100];
    int n = 0, x, i, j;

    scanf("%d", &x);

    while (x != 0) {
        v[n++] = x;
        scanf("%d", &x);
    }

    printf("inserisci x: ");
    scanf("%d", &x);

    i = 0;
    while (i < n && v[i] < x)
        i++;

    for (j = n - 1; j >= i; j--) {
        v[j + 1] = v[j];
    }

    v[i] = x;   // <--- MANCAVA QUESTO
    n++;

    for (int y = 0; y < n; y++) {
        printf("%d\n", v[y]);
    }

    return 0;
}


int main(){
	int v[100];
    int n = 10, x, i, j=0,o=0;  
    while (o<n){
    	
    	scanf("%d",&x);
   		int k = 0;
		i=j-1;
		
	    while (i >= 0 && v[i] > x) {
	        v[i + 1] = v[i];
	        i--;
	    }
		
		
	    v[i + 1] = x;
        j++;
		o++;	
	}
    
    printf("-----------------------------");  
	for (int y = 0; y < j; y++) {
        printf("%d\n", v[y]);
    }
    
	return 0;
}
*/

int main()
{
    int vet[10];
    
    for (int s=0; s<10; s++){
        printf("Inserisci un valore: ");
        scanf("%d", &vet[s]);
    }
    
    int j = 0;
    int ultimoScambio;
    int limite = 9;  // fino a dove controllare
    
    while(limite > 0)
    {
        ultimoScambio = 0;
        
        for (int i=0; i < limite; i++)
        {
            if(vet[i] > vet[i+1])
            {
                int temp = vet[i];
                vet[i] = vet[i+1];
                vet[i+1] = temp;
                
                ultimoScambio = i;  // salva la posizione dell'ultimo scambio
            }
        }
        
        limite = ultimoScambio;  // la prossima volta controlla solo fino a qui
        j++;
    }
    
    printf("Per farlo ci hai messo %d giri\n", j);
    for (int y=0; y<10; y++){
        printf("%d\n", vet[y]);
    }
    
    return 0;
}